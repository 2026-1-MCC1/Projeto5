﻿using System;
using System.Collections.Generic;

namespace LaboratorioTrancado
{
    class Pergunta
    {
        public string Texto { get; set; }
        public string[] Opcoes { get; set; }
        public string Resposta { get; set; }
        public string Dica { get; set; }
        public int Pontos { get; set; }

        public Pergunta(string texto, string[] opcoes, string resposta, string dica, int pontos)
        {
            Texto = texto;
            Opcoes = opcoes;
            Resposta = resposta;
            Dica = dica;
            Pontos = pontos;
        }
    }

    class Fase
    {
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public List<Pergunta> Perguntas { get; set; }

        public Fase(string nome, string descricao, List<Pergunta> perguntas)
        {
            Nome = nome;
            Descricao = descricao;
            Perguntas = perguntas;
        }
    }

    class Program
    {
        static int energia = 100;
        static int pontos = 0;

        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.Title = "Laboratório Trancado";

            // ── Estrutura de dados do jogo ──────────────────────────────────
            List<Fase> fases = new List<Fase>
            {
                new Fase(
                    "FASE 1 — A Sala dos Servidores",
                    "Para passar pela primeira porta, responda perguntas de lógica computacional.",
                    new List<Pergunta>
                    {
                        new Pergunta(
                            "Em um loop while, o que acontece se a condição NUNCA se tornar falsa?",
                            new string[] {
                                "A) O programa encerra normalmente",
                                "B) Ocorre um loop infinito",
                                "C) O compilador corrige automaticamente",
                                "D) O laço executa apenas uma vez"
                            },
                            "b",
                            "Pense no que controla a saída do while...",
                            30
                        ),
                        new Pergunta(
                            "Qual operador verifica se dois valores são IGUAIS em C#?",
                            new string[] {
                                "A) =",
                                "B) !=",
                                "C) ==",
                                "D) =>"
                            },
                            "c",
                            "Um único '=' é atribuição, não comparação.",
                            20
                        )
                    }
                ),
                new Fase(
                    "FASE 2 — O Corredor das Variáveis",
                    "A segunda porta exige conhecimento sobre variáveis e operadores.",
                    new List<Pergunta>
                    {
                        new Pergunta(
                            "Qual é o valor de x ao final?\n  int x = 5;\n  x = x + 3;\n  x = x * 2;",
                            new string[] {
                                "A) 10",
                                "B) 16",
                                "C) 13",
                                "D) 8"
                            },
                            "b",
                            "Execute passo a passo: 5 → 8 → ?",
                            25
                        ),
                        new Pergunta(
                            "Qual estrutura em C# armazena pares CHAVE e VALOR?",
                            new string[] {
                                "A) int[]",
                                "B) List<T>",
                                "C) Dictionary<K,V>",
                                "D) Queue<T>"
                            },
                            "c",
                            "Pense em um dicionário de verdade: palavra → definição.",
                            25
                        ),
                        new Pergunta(
                            "Qual é o resultado de:  10 % 3  (operador módulo)?",
                            new string[] {
                                "A) 3",
                                "B) 0",
                                "C) 1",
                                "D) 3.33"
                            },
                            "c",
                            "Módulo é o RESTO da divisão inteira.",
                            30
                        )
                    }
                ),
                new Fase(
                    "FASE 3 — A Porta Principal",
                    "O desafio final! Resolva os enigmas para destrancar a saída.",
                    new List<Pergunta>
                    {
                        new Pergunta(
                            "Quantas vezes 'oi' é impresso?\n  int i = 0;\n  while (i < 4) {\n      Console.WriteLine(\"oi\");\n      i++;\n  }",
                            new string[] {
                                "A) 3",
                                "B) 4",
                                "C) 5",
                                "D) Infinitas"
                            },
                            "b",
                            "Trace: i=0,1,2,3 → condição falha em i=4.",
                            30
                        ),
                        new Pergunta(
                            "O que a palavra-chave 'return' faz dentro de um método?",
                            new string[] {
                                "A) Imprime um valor na tela",
                                "B) Encerra o programa inteiro",
                                "C) Retorna um valor e termina o método",
                                "D) Declara uma variável global"
                            },
                            "c",
                            "return ≠ Console.WriteLine. Um devolve, o outro exibe.",
                            35
                        ),
                        new Pergunta(
                            "Qual estrutura condicional avalia múltiplos casos com elegância em C#?",
                            new string[] {
                                "A) for",
                                "B) while",
                                "C) switch",
                                "D) try/catch"
                            },
                            "c",
                            "Existe uma estrutura feita EXATAMENTE pra isso.",
                            35
                        )
                    }
                )
            };

            // ── Introdução ──────────────────────────────────────────────────
            Intro();

            string entrada = Console.ReadLine()?.Trim().ToLower();

            if (entrada == "sair")
            {
                Desistencia();
                return;
            }

            if (entrada != "jogar")
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nComando inválido. Iniciando o jogo mesmo assim...");
                Console.ResetColor();
            }

            // ── Loop principal do jogo (while) ──────────────────────────────
            bool jogando = true;
            int faseIndex = 0;

            while (jogando && energia > 0 && faseIndex < fases.Count)
            {
                Fase fase = fases[faseIndex];
                bool faseOk = ExecutarFase(fase, faseIndex + 1, fases.Count);

                if (!faseOk)
                {
                    // Jogador escolheu sair durante a fase
                    Desistencia();
                    return;
                }

                faseIndex++;

                if (energia <= 0)
                {
                    jogando = false;
                }
                else if (faseIndex < fases.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\nVocê ouve um clique mecânico. Próxima porta desbloqueada...");
                    Console.ResetColor();
                    Console.WriteLine("\nPressione ENTER para continuar...");
                    Console.ReadLine();
                }
            }

            // ── Resultado final ─────────────────────────────────────────────
            if (energia <= 0)
            {
                GameOver();
            }
            else if (faseIndex >= fases.Count)
            {
                Vitoria();
            }
        }

        // ── Executa uma fase completa ────────────────────────────────────────
        static bool ExecutarFase(Fase fase, int numFase, int totalFases)
        {
            Console.Clear();
            ExibirHUD();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"\n┌─────────────────────────────────────────────────┐");
            Console.WriteLine($"│  {fase.Nome,-47}│");
            Console.WriteLine($"└─────────────────────────────────────────────────┘");
            Console.ResetColor();

            Console.WriteLine(fase.Descricao);

            int perguntaIndex = 0;

            // While para iterar pelas perguntas da fase
            while (perguntaIndex < fase.Perguntas.Count && energia > 0)
            {
                Pergunta p = fase.Perguntas[perguntaIndex];
                bool acertou = false;

                // While para permitir repetição até acertar ou sair
                while (!acertou && energia > 0)
                {
                    ExibirHUD();
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"\n❓ PERGUNTA {perguntaIndex + 1}/{fase.Perguntas.Count}:");
                    Console.ResetColor();

                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine(p.Texto);
                    Console.ResetColor();

                    Console.WriteLine();
                    foreach (string opcao in p.Opcoes)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("   " + opcao);
                    }
                    Console.ResetColor();

                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.WriteLine("\nDigite A, B, C ou D  (ou 'dica' / 'sair'):");
                    Console.ResetColor();

                    Console.Write("❯ ");
                    string resp = Console.ReadLine()?.Trim().ToLower();

                    if (resp == "sair")
                        return false;

                    if (resp == "dica")
                    {
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine($"💡 DICA: {p.Dica}");
                        Console.ResetColor();
                        Console.WriteLine("Pressione ENTER para tentar novamente...");
                        Console.ReadLine();
                        continue;
                    }

                    if (resp != "a" && resp != "b" && resp != "c" && resp != "d")
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("⚠  Digite apenas A, B, C, D, 'dica' ou 'sair'.");
                        Console.ResetColor();
                        Console.WriteLine("Pressione ENTER...");
                        Console.ReadLine();
                        continue;
                    }

                    if (resp == p.Resposta)
                    {
                        pontos += p.Pontos;
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($"\n✔  CORRETO! +{p.Pontos} pontos");
                        Console.ResetColor();
                        acertou = true;
                        System.Threading.Thread.Sleep(800);
                    }
                    else
                    {
                        energia -= 20;
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($"\n✘  ERRADO! A resposta era: {p.Resposta.ToUpper()} — -20 de energia");
                        Console.ResetColor();
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine($"💡 DICA: {p.Dica}");
                        Console.ResetColor();

                        if (energia <= 0)
                            return true;

                        Console.WriteLine("\nTente novamente! Pressione ENTER...");
                        Console.ReadLine();
                    }
                }

                perguntaIndex++;
            }

            // Fase concluída
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n╔══════════════════════╗");
            Console.WriteLine("║  FASE CONCLUÍDA!  ✓  ║");
            Console.WriteLine("╚══════════════════════╝");
            Console.ResetColor();

            return true;
        }

        // ── Exibe o HUD no topo ──────────────────────────────────────────────
        static void ExibirHUD()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("────────────────────────────────────────────────────");
            Console.ResetColor();

            string barraEnergia = GerarBarra(energia, 100, 20);
            ConsoleColor corEnergia = energia > 50 ? ConsoleColor.Green :
                                      energia > 25 ? ConsoleColor.Yellow : ConsoleColor.Red;

            Console.Write(" ENERGIA: ");
            Console.ForegroundColor = corEnergia;
            Console.Write($"[{barraEnergia}] {energia}/100");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write($"   PONTOS: {pontos}");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\n────────────────────────────────────────────────────");
            Console.ResetColor();
        }

        static string GerarBarra(int valor, int maximo, int tamanho)
        {
            int preenchido = (int)Math.Round((double)valor / maximo * tamanho);
            string barra = new string('█', preenchido) + new string('░', tamanho - preenchido);
            return barra;
        }

        // ── Telas de início e fim ────────────────────────────────────────────
        static void Intro()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("╔══════════════════════════════════════════════════╗");
            Console.WriteLine("║     LABORATÓRIO TRANCADO — ESCAPE DO LAB!        ║");
            Console.WriteLine("╚══════════════════════════════════════════════════╝");
            Console.ResetColor();

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Você acorda no escuro.");
            System.Threading.Thread.Sleep(500);
            Console.WriteLine("São 23h47. O laboratório de informática está fechado.");
            System.Threading.Thread.Sleep(500);
            Console.WriteLine("Você dormiu enquanto estudava e o segurança trancou tudo.");
            System.Threading.Thread.Sleep(500);
            Console.WriteLine("Seu celular está sem bateria. A única saída é pela porta eletrônica.");
            Console.ResetColor();

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("O painel exige que você prove seus conhecimentos.");
            Console.WriteLine("Passe pelas 3 fases para desbloquear a saída!");
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            Console.ResetColor();

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("  [ ACERTO ]  →  +pontos de XP");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("  [ ERRO ]    →  -20 de energia  (dica gratuita!)");
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("  [ sair ]    →  desiste e espera alguém abrir...");
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("  [ dica ]    →  pede ajuda (não perde energia)");
            Console.ResetColor();

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Para continuar, digite  \"jogar\"  ou  \"sair\":");
            Console.ResetColor();
            Console.Write("❯ ");
        }

        static void Vitoria()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("╔══════════════════════════════════════════════════╗");
            Console.WriteLine("║       🏆  VOCÊ ESCAPOU DO LABORATÓRIO!           ║");
            Console.WriteLine("╚══════════════════════════════════════════════════╝");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\nA porta principal se abre.");
            Console.WriteLine("Você respira o ar fresco da madrugada.");
            Console.WriteLine("Sua dedicação ao conhecimento foi sua chave de saída!");
            Console.ResetColor();

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"PONTUAÇÃO FINAL: {pontos} XP");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"ENERGIA RESTANTE: {energia}/100");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\n═══ FIM DE JOGO ════════════════════════════════════");
            Console.ResetColor();
            Console.WriteLine("\nPressione ENTER para sair...");
            Console.ReadLine();
        }

        static void GameOver()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("╔══════════════════════════════════════════════════╗");
            Console.WriteLine("║        💀  ENERGIA ESGOTADA — GAME OVER          ║");
            Console.WriteLine("╚══════════════════════════════════════════════════╝");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\nVocê fica exausto e acaba adormecendo de novo no chão.");
            Console.WriteLine("O segurança te encontra de manhã. Constrangedor...");
            Console.ResetColor();

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"PONTUAÇÃO FINAL: {pontos} XP");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\n═══ FIM DE JOGO ════════════════════════════════════");
            Console.ResetColor();
            Console.WriteLine("\nPressione ENTER para sair...");
            Console.ReadLine();
        }

        static void Desistencia()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\nVocê escolheu esperar...");
            Console.WriteLine("Às 06h30 o segurança abre o laboratório e te encontra dormindo na cadeira.");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\"Isso de novo?!\" — ele diz.");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine($"\nPONTUAÇÃO FINAL: {pontos} XP  (desistência)");
            Console.WriteLine("\n═══ FIM DE JOGO ════════════════════════════════════");
            Console.ResetColor();
            Console.WriteLine("\nPressione ENTER para sair...");
            Console.ReadLine();
        }
    }
}