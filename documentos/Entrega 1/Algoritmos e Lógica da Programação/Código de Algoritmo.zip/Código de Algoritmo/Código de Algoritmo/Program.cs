﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int energia = 3;   // energia inicial
        int pontos = 0;    // pontuação inicial
        bool venceu = false;

        Console.WriteLine("Você acordou preso no laboratório de informática!");
        Console.WriteLine("Para sair, precisa passar por 3 fases de desafios.");
        Console.WriteLine("Digite 'sair' a qualquer momento para desistir.\n");

        // === FASE 1 ===
        while (energia > 0)
        {
            Console.WriteLine("=== Fase 1 ===");
            Console.WriteLine("Pergunta: Qual linguagem estamos usando neste jogo?");
            string resposta = Console.ReadLine();

            if (resposta.ToLower()== "sair") //ToLower() transforma todas as letras em Maiúsculo para não causar problema
            {
                Console.WriteLine("Você desistiu e vai esperar alguém abrir o laboratório...");
                return; // encerra o jogo
            }

            if (resposta.ToLower() == "c#")
            {
                pontos += 10;
                Console.WriteLine("Correto! Pontos: " + pontos);
                break; // sai do loop da fase 1 e vai para a próxima
            }
            else
            {
                energia--;
                Console.WriteLine("Errado! Energia restante: " + energia);
            }
        }

        if (energia == 0) { Console.WriteLine("Você perdeu toda a energia... ficará preso."); return; }

        // === FASE 2 ===
        while (energia > 0)
        {
            Console.WriteLine("\n=== Fase 2 ===");
            Console.WriteLine("Pergunta: Qual comando usamos para repetir até uma condição ser falsa?");
            string resposta = Console.ReadLine();

            if (resposta.ToLower() == "sair")
            {
                Console.WriteLine("Você desistiu e vai esperar alguém abrir o laboratório...");
                return;
            }

            if (resposta.ToLower() == "while")
            {
                pontos += 10;
                Console.WriteLine("Correto! Pontos: " + pontos);
                break; // avança para fase 3
            }
            else
            {
                energia--;
                Console.WriteLine("Errado! Energia restante: " + energia);
            }
        }

        if (energia == 0) { Console.WriteLine("Você perdeu toda a energia... ficará preso."); return; }

        // === FASE 3 ===
        while (energia > 0)
        {
            Console.WriteLine("\n=== Fase 3 ===");
            Console.WriteLine("Pergunta: Qual operador usamos para comparar igualdade?");
            string resposta = Console.ReadLine();

            if (resposta.ToLower() == "sair")
            {
                Console.WriteLine("Você desistiu e vai esperar alguém abrir o laboratório...");
                return;
            }

            if (resposta == "==")
            {
                pontos += 10;
                Console.WriteLine("Correto! Pontos: " + pontos);
                venceu = true;
                break; // termina o jogo
            }
            else
            {
                energia--;
                Console.WriteLine("Errado! Energia restante: " + energia);
            }
        }

        // Resultado final
        if (venceu)
        {
            Console.WriteLine("\nParabéns! Você destrancou o laboratório e saiu!");
            Console.WriteLine("Pontuação final: " + pontos);
        }
        else
        {
            Console.WriteLine("\nVocê perdeu toda a energia... ficará preso até alguém abrir.");
        }
    }
}